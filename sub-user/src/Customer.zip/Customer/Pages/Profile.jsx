import React from "react";
import ProfileHeader from "../Components/ProfileHeader";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const navigate = useNavigate();

  const user = {
    name: "Xyz",
    email: "xyz@gmail.com",
    phone: "+91 9875432341",
  };
  return (
    <div className="min-h-screen bg-[#FAFAF7] py-10">
      <div className="max-w-xl mx-auto px-6">
        <ProfileHeader user={user} onEdit={() => navigate("/profile/edit")} />
      </div>
    </div>
  );
};

export default Profile;
